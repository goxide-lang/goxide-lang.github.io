# Orders tutorial: go

用 Go 的结构体、状态常量和 switch 写一个订单状态 CLI。

Use Go 1.27+. Extract every file together.

Compiler: https://github.com/goxide-lang/goxide/tree/92b0a0c42d904b338afee48c04c6d1293427708c

Verified toolchain: go version go1.27.3 darwin/arm64

```sh
go build -o ../orders .
go run .
go test -count=1 ./...
```

Expected program output:

```text
order 1001: pending
order 1002: paid 42
order 1003: shipped TRACK-7
```
