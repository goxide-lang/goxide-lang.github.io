# Orders tutorial: go

用 Go 的结构体、状态常量和 switch 写一个订单状态 CLI。

Use Go 1.27+. Extract every file together.

Compiler worktree based on fba740a24e802028954229f1ba19cda7af60451c; SHA-256 1121cc56f12dea79f6dcdbf4bcc030d94bd238100da19b9a17f4a44d1e42ef98

Verified toolchain: go version go1.27.2 darwin/arm64

```sh
go build -o ../orders .
go run .
go test -count=1 ./...
```

Expected program output:

```text
order 1001: pending
order 1002: paid 42
order 1003: shipped TRACK-7
```
