# Orders tutorial: mixed

保留 go.mod、Go 入口和 Go 测试，用 enum 与 match 替换状态表示。

Use the matching goxide CLI and go1.27.3 (exact version, including the patch). Extract every file together.

Compiler: https://github.com/goxide-lang/goxide/tree/17d9ae56a552e4910fda7fcb5482a8cabc0fa339

Verified toolchain: go version go1.27.3 linux/amd64

```sh
go generate ./...
go build -o ../orders .
go run .
go test -count=1 ./...
```

Expected program output:

```text
order 1001: pending
order 1002: paid 42
order 1003: shipped TRACK-7
```
