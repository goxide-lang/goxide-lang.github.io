# Orders tutorial: mixed

保留 go.mod、Go 入口和 Go 测试，用 enum 与 match 替换状态表示。

Use the matching goxide CLI and Go 1.27+. Extract every file together.

Compiler worktree based on 6a80c526216b4d24597089bbebed6e15a3331974; SHA-256 edcbd910796749b2e7e5a42a5b6ccf1362a5d234855a2d032cb3cd6aa8d52f25

Verified toolchain: go version go1.27.1 darwin/arm64

```sh
go generate ./...
go build -o ../orders .
go run .
go test -count=1 ./...
```

Expected program output:

```text
order 1001: pending
order 1002: paid 42
order 1003: shipped TRACK-7
```
