# Reproduce this project

Use the matching goxide CLI and Go 1.27+. Extract all files together and run these commands in this directory. The target directory is generated; no build scripts are required.

Compiler: https://github.com/goxide-lang/goxide/tree/690cd5178dc11a0089a41e9320ed1275778383e1

Verified toolchain: go version go1.27.1 linux/amd64

```sh
goxide build --bin hello --locked .  # first build may download pinned support dependencies
goxide run --bin hello --offline --locked .
goxide run --bin hello --no-default-features --offline --locked .
goxide run --bin inspect --offline --locked .
goxide run --example greet --offline --locked .
goxide build --lib --offline --locked .
```
