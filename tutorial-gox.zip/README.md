# Orders tutorial: gox

业务和测试都使用 .gox，以 goxide.toml 声明模块、包名映射和命令入口。

Use the matching goxide CLI and go1.27.2 (exact version, including the patch). Extract every file together.

Compiler worktree based on fba740a24e802028954229f1ba19cda7af60451c; SHA-256 1121cc56f12dea79f6dcdbf4bcc030d94bd238100da19b9a17f4a44d1e42ef98

Verified toolchain: go version go1.27.2 darwin/arm64

```sh
goxide build --offline .
goxide gen --offline --locked -o ../gox-generated-default .
goxide build --offline --locked -o ../orders .
goxide run --offline --locked .
goxide test --offline --locked .
```

Expected program output:

```text
order 1001: pending
order 1002: paid 42
order 1003: shipped TRACK-7
```
