# Orders tutorial: gox

业务和测试都使用 .gox，以 goxide.toml 声明模块、包名映射和命令入口。

Use the matching goxide CLI and go1.27.3 (exact version, including the patch). Extract every file together.

Compiler: https://github.com/goxide-lang/goxide/tree/8112e7ccf71218d7d117d5be44b4180437cb8b09

Verified toolchain: go version go1.27.3 linux/amd64

```sh
goxide build --offline .
goxide gen --offline --locked -o ../gox-generated-default .
goxide build --offline --locked -o ../orders .
goxide run --offline --locked .
goxide test --offline --locked .
```

Expected program output:

```text
order 1001: pending
order 1002: paid 42
order 1003: shipped TRACK-7
```
