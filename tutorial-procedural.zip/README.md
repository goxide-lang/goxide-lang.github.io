# Procedural macros: function, attribute and derive

The consumer and macro producer are separate Goxide modules. The macro module uses the published syntax SDK and compiles to restricted WASI.

Compiler: bd95b47401267b17ac20b81924ae10e21c373559; SHA-256 8a550b89e1fe7428e05c10ae26548410ff39dcd5c47c3eace4b622de155c82a5

Verified toolchain: go version go1.27.3 darwin/arm64

```sh
goxide build .
goxide run --offline --locked .
goxide test --offline --locked .
goxide gen --offline --locked -o ../generated .
```

First build may download the pinned SDK; after moving the project, build without --locked to record its new local path. Subsequent locked commands preserve that lock.

Expected output:

```text
42 42 Order
```

`twice!` evaluates its expression once. `#[constant(expr)]` replaces a function body. `#[derive(TypeName)]` parses a concrete type and adds its public typeName method.
