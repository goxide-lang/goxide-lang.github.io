# Procedural macros: function, attribute and derive

The consumer and macro producer are separate Goxide modules. The macro module uses the published syntax SDK and compiles to restricted WASI.

Compiler: 92b0a0c42d904b338afee48c04c6d1293427708c; SHA-256 dc1485e6f18c2ceff104d465df56ceb332935d49f97d49e3a801d13485c02816

Verified toolchain: go version go1.27.3 darwin/arm64

```sh
goxide build .
goxide run --offline --locked .
goxide test --offline --locked .
goxide gen --offline --locked -o ../generated .
```

First build may download the pinned SDK; after moving the project, build without --locked to record its new local path. Subsequent locked commands preserve that lock.

Expected output:

```text
42 42 Order
```

`twice!` evaluates its expression once. `#[constant(expr)]` replaces a function body. `#[derive(TypeName)]` parses a concrete type and adds its public typeName method.
