# Procedural macros: function, attribute and derive

The consumer and macro producer are separate Goxide modules. The macro module uses the published syntax SDK and compiles to restricted WASI.

Compiler: 8112e7ccf71218d7d117d5be44b4180437cb8b09; SHA-256 ad9cc553ba37a08ac7ba04130e59a6719c49c6945f65bdf7ce98de7992f668c3

Verified toolchain: go version go1.27.3 linux/amd64

```sh
goxide build .
goxide run --offline --locked .
goxide test --offline --locked .
goxide gen --offline --locked -o ../generated .
```

First build may download the pinned SDK; after moving the project, build without --locked to record its new local path. Subsequent locked commands preserve that lock.

Expected output:

```text
42 42 Order
```

`twice!` evaluates its expression once. `#[constant(expr)]` replaces a function body. `#[derive(TypeName)]` parses a concrete type and adds its public typeName method.
