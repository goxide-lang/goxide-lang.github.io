# Procedural macros: function, attribute and derive

The consumer and macro producer are separate Goxide modules. The macro module uses the published syntax SDK and compiles to restricted WASI.

Compiler: 17d9ae56a552e4910fda7fcb5482a8cabc0fa339; SHA-256 d9ff208da140f6dc453096ee3fccee36b0f848071c43449cc582b938635ffc64

Verified toolchain: go version go1.27.3 linux/amd64

```sh
goxide build .
goxide run --offline --locked .
goxide test --offline --locked .
goxide gen --offline --locked -o ../generated .
```

First build may download the pinned SDK; after moving the project, build without --locked to record its new local path. Subsequent locked commands preserve that lock.

Expected output:

```text
42 42 Order
```

`twice!` evaluates its expression once. `#[constant(expr)]` replaces a function body. `#[derive(TypeName)]` parses a concrete type and adds its public typeName method.
