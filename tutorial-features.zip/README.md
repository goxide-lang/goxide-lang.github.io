# Orders tutorial: features

切换 pretty、trace 和 report，并向本地可选 reporter 模块转发 feature。

Use the matching goxide CLI and go1.27.3 (exact version, including the patch). Extract every file together.

Compiler: https://github.com/goxide-lang/goxide/tree/17d9ae56a552e4910fda7fcb5482a8cabc0fa339

Verified toolchain: go version go1.27.3 linux/amd64

```sh
goxide build --offline .
goxide gen --offline --locked -o ../features-generated-default .
goxide build --offline --locked -o ../orders .
goxide run --offline --locked .
goxide test --offline --locked .
```

Expected program output:

```text
[orders] order 1001: pending
[orders] order 1002: paid 42
[orders] order 1003: shipped TRACK-7
```

The archive contains the default build lock. After moving this local-path project, or activating report for the first time, run build without --locked to record the module plan at the current location. Then use --locked --offline there.

Feature presets:

```sh
goxide build --offline .
goxide run --offline --locked .
goxide build --offline --no-default-features .
goxide run --offline --locked --no-default-features .
goxide build --offline --features=trace .
goxide run --offline --locked --features=trace .
goxide build --offline --features=report .
goxide run --offline --locked --features=report .
```

`report` activates `dep:reporter` and forwards `reporter/pretty`. The local reporter is a separate Goxide module in `reporter/`; no workspace is needed.
