# Reproduce the reexports directory example

Use the matching goxide CLI and Go 1.27+. Extract every file together. The directory uses go.mod and goxide.roots.toml; no build scripts are required.

Compiler worktree based on 0df22b6f81d387c697934309f4230e3074944ff8; SHA-256 edcbd910796749b2e7e5a42a5b6ccf1362a5d234855a2d032cb3cd6aa8d52f25

Verified toolchain: go version go1.27.1 darwin/arm64

```sh
goxide build -o ../reexports .
goxide run .
```

Expected output:

```text
shared 2 2 true
42 2 7
```
