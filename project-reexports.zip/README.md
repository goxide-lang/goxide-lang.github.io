# Reproduce the reexports directory example

Use the matching goxide CLI and go1.27.3 (exact version, including the patch). Extract every file together. The directory uses go.mod and goxide.roots.toml; no build scripts are required.

Compiler: https://github.com/goxide-lang/goxide/tree/17d9ae56a552e4910fda7fcb5482a8cabc0fa339

Verified toolchain: go version go1.27.3 linux/amd64

```sh
goxide build -o ../reexports .
goxide run .
```

Expected output:

```text
shared 2 2 true
42 2 7
```
