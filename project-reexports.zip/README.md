# Reproduce the reexports directory example

Use the matching goxide CLI and go1.27.3 (exact version, including the patch). Extract every file together. The directory uses go.mod and goxide.roots.toml; no build scripts are required.

Compiler: https://github.com/goxide-lang/goxide/tree/92b0a0c42d904b338afee48c04c6d1293427708c

Verified toolchain: go version go1.27.3 darwin/arm64

```sh
goxide build -o ../reexports .
goxide run .
```

Expected output:

```text
shared 2 2 true
42 2 7
```
