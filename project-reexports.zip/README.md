# Reproduce the reexports directory example

Use the matching goxide CLI and go1.27.3 (exact version, including the patch). Extract every file together. The directory uses go.mod and goxide.roots.toml; no build scripts are required.

Compiler: https://github.com/goxide-lang/goxide/tree/bd95b47401267b17ac20b81924ae10e21c373559

Verified toolchain: go version go1.27.3 darwin/arm64

```sh
goxide build -o ../reexports .
goxide run .
```

Expected output:

```text
shared 2 2 true
42 2 7
```
