# Reproduce the reexports directory example

Use the matching goxide CLI and go1.27.3 (exact version, including the patch). Extract every file together. The directory uses go.mod and goxide.roots.toml; no build scripts are required.

Compiler: https://github.com/goxide-lang/goxide/tree/8112e7ccf71218d7d117d5be44b4180437cb8b09

Verified toolchain: go version go1.27.3 linux/amd64

```sh
goxide build -o ../reexports .
goxide run .
```

Expected output:

```text
shared 2 2 true
42 2 7
```
